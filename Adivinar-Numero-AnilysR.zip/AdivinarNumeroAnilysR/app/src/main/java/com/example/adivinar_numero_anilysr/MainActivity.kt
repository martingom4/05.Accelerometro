package com.example.adivinar_numero_anilysr

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.jvm.java
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private val secretNumber = Random.nextInt(0, 101)
    private val maxAttempts = 3
    private val maxTimeMillis = 60000L // 1 minuto

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val context = this@MainActivity

            GuessNumberGame(secretNumber, maxAttempts, maxTimeMillis) { result, number ->
                val intent = Intent(context, MainActivity::class.java)
                intent.putExtra("resultMessage", result)
                intent.putExtra("correctNumber", number)
                startActivity(intent)
                finish()
            }
        }
    }

}

@Composable
fun GuessNumberGame(
    secretNumber: Int,
    maxAttempts: Int,
    maxTimeMillis: Long,
    onGameEnd: (String, Int) -> Unit
) {
    var guessInput by remember { mutableStateOf("") }
    var hintText by remember { mutableStateOf("") }
    var attempts by remember { mutableStateOf(0) }
    var timeLeft by remember { mutableStateOf((maxTimeMillis / 1000).toInt()) }
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        object : CountDownTimer(maxTimeMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeft = (millisUntilFinished / 1000).toInt()
            }

            override fun onFinish() {
                onGameEnd("¡Tiempo agotado!", secretNumber)
            }
        }.start()
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFFD8EAFE), Color(0xFFB0D6F7))
                )
            ),
        color = Color.Transparent
    ) {
        var gameOver by remember { mutableStateOf(false) }
        var showNumber by remember { mutableStateOf(false) }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Juego: Adivina el número", fontSize = 24.sp, color = Color(0xFF1B365C))
            Spacer(modifier = Modifier.height(12.dp))
            Text("Tienes $maxAttempts intentos y $timeLeft segundos", fontSize = 16.sp)
            Spacer(modifier = Modifier.height(28.dp))

            if (!gameOver) {
                OutlinedTextField(
                    value = guessInput,
                    onValueChange = { guessInput = it },
                    label = { Text("Ingresa un número del 0 al 100") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(onClick = {
                    val guess = guessInput.toIntOrNull()
                    if (guess == null || guess !in 0..100) {
                        hintText = "Número inválido, intenta entre 0 y 100"
                        return@Button
                    }

                    attempts++
                    if (guess == secretNumber) {
                        gameOver = true
                        hintText = "¡Ganaste!"
                    } else if (attempts >= maxAttempts) {
                        gameOver = true
                        showNumber = true
                        hintText = "¡Perdiste!"
                    } else {
                        hintText = if (guess < secretNumber) "El número es mayor" else "El número es menor"
                    }
                }) {
                    Text("Adivinar")
                }

                Spacer(modifier = Modifier.height(24.dp))
                Text(text = hintText, fontSize = 18.sp, color = Color.Black)
            } else {
                Text(text = hintText, fontSize = 22.sp, color = Color.Red)
                Spacer(modifier = Modifier.height(16.dp))
                if (showNumber) {
                    Text("El número correcto era: $secretNumber", fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                }

                Button(onClick = {
                    // Reiniciar juego
                    guessInput = ""
                    attempts = 0
                    timeLeft = (maxTimeMillis / 1000).toInt()
                    gameOver = false
                    showNumber = false
                    hintText = ""

                }) {
                    Text("Intentar de nuevo")
                }
            }
        }
    }
}